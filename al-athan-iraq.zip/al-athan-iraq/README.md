# Al-Athan Iraq (Android TV)

A from-scratch native Android TV app (Kotlin) for Iraqi prayer times. This is
original code with its own branding — it is **not** derived from or a
repackaging of any existing prayer-times app (e.g. Mawaqit). That's
intentional: modifying and redistributing someone else's app under a new
name/logo would be a copyright violation, so this project builds the same
kind of functionality independently.

## What's included

- **Two home screen designs**, switchable anytime from Settings → Change Home
  Screen (hamburger menu → Change Home Screen):
  - **Dashboard** (default) — `DashboardMainActivity`: live digital clock,
    Gregorian+Hijri date line, online/offline status indicator, Shuruk
    (sunrise) and Jumua (Friday prayer) times, and icon-per-prayer cards.
  - **Classic** — `MainActivity`: the simpler stacked design from earlier
    iterations.
  Both have portrait (phone) and landscape (TV / phone rotated) layout
  variants sharing one Kotlin binding class each, same pattern as before.
  `SplashActivity` and `MenuActivity` both consult `HomeScreenRouter` so
  Splash launches the right one and switching designs in Settings correctly
  hands off from whichever is currently open.
- **Dashboard specifics**:
  - Live clock (`DateFormatting.currentClockTime()`) ticks every second in
    12-hour format with seconds, e.g. "05:30:35 PM".
  - Online/offline indicator (`NetworkStatus.kt`) — a gold dot + "Online"
    when connected, gray dot + "Offline" when not, updated live via
    `ConnectivityManager.NetworkCallback` while the screen is open.
  - Hamburger button glows gold (`hamburger_glow_bg.xml`) when D-pad focus
    lands on it (TV/remote) or on touch press (phone) — matches the app's
    consistent gold selection color everywhere else.
  - Shuruk (sunrise) comes straight from the Aladhan API's `sunrise` field.
    Jumua (Friday prayer) is computed as Dhuhr + a configurable offset
    (default 10 min, matching the reference design) — there's no separate
    "Jumua" field in the API, so this mirrors how the Iqama offsets work.
    Adjust it in Settings → Jumua (Friday Prayer) Times Adjustment (its own
    screen — see below), not in Iqama anymore.
  - All Dashboard prayer/Shuruk/Jumua/clock times are shown in 12-hour
    format with AM/PM; Classic keeps 24-hour format.

- **Governorate → District → Sub-district** (`DistrictPickerActivity`):
  location selection is now up to three steps deep. Most districts still
  have no sub-districts (the district itself remains directly selectable —
  pick "Use \<District\> (no specific sub-district)" at the sub-district step,
  or just pick a district that has none). One sub-district is populated as a
  working example: **Harir**, under Shaqlawa in Erbil governorate — see
  `IraqRegions.kt` (`SubDistrict`) to add more following the same pattern;
  populating every district's sub-districts nationwide is out of scope here.
  The home screen shows only the most specific name selected (sub-district
  if set, otherwise district) — never the governorate.
- **Use My Location (GPS)**: a button on the governorate picker screen
  (`LocationHelper.kt`) requests location permission, gets a GPS/network fix
  (cached last-known first, falling back to a fresh single-update request
  with a 12s timeout), and matches it to the nearest district or
  sub-district via haversine distance (`IraqRegions.nearestTo()`). Fails
  gracefully to the manual picker if permission is denied, no provider is
  available, or the device (e.g. most Android TVs) has no location hardware
  at all.
- **Jumua (Friday Prayer) Times Adjustment** (`JumuaSettingsActivity`), its
  own menu item separate from Iqama: either "Match Jumua to Dhuhr" exactly,
  or a +/- minute offset relative to Dhuhr that can go negative (Jumua
  called *before* Dhuhr's adhan) as well as positive. Removed from the
  Iqama settings screen, which now only covers the 5 daily prayers.
- **Color Scheme** (`ColorSchemePickerActivity` / `ColorSchemes.kt`): 5
  curated presets (Teal & Gold, Midnight & Silver, Emerald & Gold, Royal
  Purple & Gold, Slate & Sky Blue), each shown as a button rendered in its
  own colors. Applied at runtime to prayer card text, "Next prayer in" +
  the countdown, the clock/date card text, and the screen background — on
  both Dashboard and Classic. This is a curated palette picker, not a full
  custom RGB color picker; add more presets in `ColorSchemes.kt` if you
  want finer control.

- **Runs on Android TV and Android phones**, in both portrait and landscape.
  Two layout variants share one Kotlin `ActivityMainBinding`:
  `res/layout/activity_main.xml` (portrait / default — stacked vertically,
  scrollable, 2-column prayer grid) and `res/layout-land/activity_main.xml`
  (landscape — used on TV and on phones rotated sideways — the original
  wide single-row design). No orientation lock in the manifest anymore, so
  the OS/sensor decides based on the device and the user's rotation setting.
  `android.software.leanback` is now `required="false"` so the app installs
  on phones too, not just TV.
- **Splash screen**: dedicated, non-distorted images per orientation —
  `res/drawable-port-nodpi/splash_screen.png` (portrait, phones) and
  `res/drawable-land-nodpi/splash_screen.png` (landscape, TV / rotated
  phones) — each shown edge-to-edge via `SplashActivity` for ~2 seconds,
  then handed off to whichever home screen design is active.
- **Home screen**:
  - Hamburger menu button, top-left corner. Opens a menu
    (`MenuActivity`) with, in order: **Change Location**, **Iqama**,
    **Change Home Screen**, **Color Scheme**, **Jumua (Friday Prayer) Times
    Adjustment**, **About**.
  - Mosque name + district/governorate name, mosque name first with the
    location next to it. Mosque name is stored in `Prefs` (default "Central
    Mosque" — set `Prefs.setMosqueName(...)` wherever makes sense for your
    install, e.g. a future settings screen).
  - Gregorian + Hijri date.
  - Live countdown to the next prayer.
  - 5 prayer-time cards (Fajr, Dhuhr, Asr, Maghrib, Isha), redesigned to
    match the latest reference image: subdued teal card, thin mint border,
    rounded corners, prayer name in regular weight above a bold adhan time.
    The iqama offset is **not** shown on these cards anymore — it's only
    visible/editable in Settings → Iqama (see below).
  - App branding lockup (logo + "Al-Athan Iraq" wordmark).
- **Governorate → District picker** (`DistrictPickerActivity`): two-step
  location selection covering all 18 Iraqi governorates and their districts
  (qadha) — e.g. Baghdad → Karkh/Rusafa/Adhamiyah/Kadhimiya/etc., Nineveh →
  Mosul/Tel Afar/Sinjar/etc. Erbil includes Mergasur and Rawanduz. Pick a
  governorate, then a district within it; the D-pad/system back button steps
  back one level before exiting the screen. See `IraqRegions.kt` to add,
  rename, or adjust coordinates for any governorate or district. The home
  screen shows the selected district and governorate together (e.g. "Karkh,
  Baghdad").
- **Iqama settings** (`IqamaSettingsActivity`): a +/- stepper per prayer to
  set how many minutes after adhan the iqama is called (0–60 min, saved
  immediately). Defaults: Fajr 20, Dhuhr 15, Asr 15, Maghrib 8, Isha 15 —
  see `Prefs.kt` (`DEFAULT_IQAMA_OFFSETS`) to change the starting values.
  This is the only place the offset is shown; the home-screen cards no
  longer display it (see above).
- **Consistent gold/yellow selection color**: every focusable element in the
  app — hamburger button, menu options, governorate/district list items,
  iqama +/- steppers, dialog buttons — highlights in the same gold accent
  (`@color/gold_accent`) whether selected via D-pad focus (TV / keyboard) or
  a touch tap (phone), via matching `state_focused`/`state_pressed` entries
  in `button_outline.xml` and `icon_button_bg.xml`.
- **About screen** (`AboutActivity`): logo, app name, version (pulled from
  `versionName` via `BuildConfig`), and a short description.
- **Prayer time source**: [Aladhan API](https://aladhan.com/prayer-times-api)
  (free, no key required), calculation method defaults to the Egyptian
  General Authority of Survey (method=2), commonly used across Iraq. You can
  change this in `AladhanApi.kt`.
- **Hijri date**: comes from the same Aladhan API response.
- **Location permission**: `ACCESS_FINE_LOCATION` / `ACCESS_COARSE_LOCATION`
  are requested only when the person taps "Use My Location" in the district
  picker — not on launch. Denying it (or running on a device with no
  location hardware, like most Android TVs) just leaves the manual
  governorate/district picker as the only option, with no crash or dead end.
- **Athan (call to prayer) audio**: `AthanScheduler` + `AthanAlarmReceiver`
  schedule an `AlarmManager` alarm for each remaining prayer today and play
  `res/raw/athan.mp3` when it fires.
- **Original branding**: app name "Al-Athan Iraq". Logo, launcher icon, TV
  banner, and splash screens are all sourced from images supplied over the
  course of this project (currently: the green mosque/clock-face logo →
  launcher icon at all mipmap densities + `res/drawable-nodpi/logo_al_athan.png`
  + generated TV banner `tv_banner_final.png`; and the green ornamental
  startup screens → `res/drawable-port-nodpi/splash_screen.png` (portrait)
  and `res/drawable-land-nodpi/splash_screen.png` (landscape)). No Mawaqit
  logo or assets anywhere in this project — replace any of these files to
  rebrand further.

## ⚠️ Before you build: add a real athan audio file

`app/src/main/res/raw/athan.mp3` is currently a **placeholder text file**,
not real audio — I can't source or embed a specific athan recording for you
without knowing its licensing. Before building:

1. Get an athan recording you have the rights to use (many reciters release
   recordings under permissive licenses — check the terms before using one).
2. Replace `app/src/main/res/raw/athan.mp3` with that file (keep the same
   filename).

Without this, the app runs fine but plays no sound at prayer time (the
receiver fails silently rather than crashing).

## Building the APK

This project includes the Gradle wrapper (`gradlew`, `gradlew.bat`,
`gradle/wrapper/gradle-wrapper.jar`), so no separate Gradle install is
needed.

1. Clone the repo (or open the folder you just downloaded from GitHub) in
   [Android Studio](https://developer.android.com/studio) (Hedgehog or
   newer) — it will sync automatically.
2. Replace `res/raw/athan.mp3` as described above.
3. Build from Android Studio (`Build > Generate Signed Bundle / APK`), or
   from a terminal:
   ```bash
   ./gradlew assembleDebug        # macOS/Linux
   gradlew.bat assembleDebug      # Windows
   ```
4. Sideload the resulting APK onto your Android TV via
   `adb install app/build/outputs/apk/debug/app-debug.apk`, or copy it to a
   USB drive and install with a file manager app.

## Pushing to GitHub

This zip is structured as a ready-to-go repo root (`.gitignore`, `LICENSE`,
Gradle wrapper included — build output and local config are already
git-ignored). To publish it:

```bash
cd al-athan-iraq
git init
git add .
git commit -m "Initial commit: Al-Athan Iraq Android TV app"
git branch -M main
git remote add origin <your-empty-github-repo-url>
git push -u origin main
```

Or, on GitHub's web UI: create a new empty repository (no README/license/
gitignore, since this zip already has them), then use "uploading an existing
file" and drag in the extracted folder contents — though the `git` route
above is recommended so the Gradle wrapper's executable bit on `gradlew` is
preserved.

## Project structure

```
app/src/main/java/com/alathaniraq/tv/
  data/     Governorate/District list (IraqRegions.kt), Aladhan API client + models, repository
  ui/       MainActivity (home screen), DistrictPickerActivity, MenuActivity,
            IqamaSettingsActivity, AboutActivity, SplashActivity
  util/     Prefs, AthanScheduler, AthanAlarmReceiver, BootReceiver, date formatting
app/src/main/res/
  layout/   activity_main.xml, activity_district_picker.xml, activity_menu.xml,
            activity_iqama_settings.xml, activity_about.xml, item_prayer_card.xml,
            item_region.xml, item_iqama_row.xml
  drawable/ Launcher icon, TV banner, card + button styles
  values/   strings.xml, colors.xml (mosque-green + teal + gold theme), themes.xml
```

## Known limitations / next steps

- Alarms are (re)scheduled only for the *remaining* prayers each time the
  app is opened (or on boot). For a fully "set and forget" install, swap
  `BootReceiver`'s activity launch for a daily `WorkManager` job that
  fetches tomorrow's timings just after midnight and reschedules.
- Location list covers the 18 governorates with a representative set of
  districts per governorate (not exhaustive down to every sub-district).
  Add more `District(...)` entries per `Governorate(...)` in
  `IraqRegions.kt` as needed, or wire up a location-based lookup.
- No offline caching yet — the app fetches from Aladhan each time it opens.
- Calculation method defaults to method=2; if you want the method used by a
  specific Iraqi religious authority, check Aladhan's docs for the closest
  match or supply custom angles.
