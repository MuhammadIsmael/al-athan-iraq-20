package com.alathaniraq.tv.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.alathaniraq.tv.R
import com.alathaniraq.tv.databinding.ActivityAthanDisplayBinding
import com.alathaniraq.tv.util.AthanAlarmReceiver
import com.alathaniraq.tv.util.NetworkStatus

/**
 * Shown automatically by AthanAlarmReceiver the moment each daily prayer's athan time
 * starts (see AthanScheduler for how the alarm gets set, and AthanAlarmReceiver for how
 * it launches this on top of whatever else is running). Deliberately keeps its own fixed
 * dark/green/gold look rather than following Settings > Color Scheme — this screen is
 * meant to always read the same way regardless of the home screen's theme, matching the
 * reference design exactly ("keep everything").
 *
 * Auto-dismisses after AUTO_DISMISS_MS, or immediately on tap/back — whichever comes
 * first — returning to whatever was showing before.
 */
class AthanDisplayActivity : BaseActivity() {

    private lateinit var binding: ActivityAthanDisplayBinding
    private val handler = Handler(Looper.getMainLooper())
    private val autoDismiss = Runnable { finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAthanDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Wake and show over the lock screen if the device was idle/locked when the
        // athan time hit — this is the whole point of the screen, so it shouldn't
        // silently fail to appear just because the display was off.
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        val prayerKey = intent.getStringExtra(AthanAlarmReceiver.EXTRA_PRAYER_NAME)
        binding.athanText.text = getString(R.string.athan_now, localizedPrayerName(prayerKey))

        binding.menuButton.setOnClickListener {
            startActivity(android.content.Intent(this, MenuActivity::class.java))
        }
        binding.root.setOnClickListener { finish() }
        binding.menuButton.requestFocus()

        setOnlineStatus(NetworkStatus.isOnline(this))
    }

    override fun onResume() {
        super.onResume()
        handler.postDelayed(autoDismiss, AUTO_DISMISS_MS)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(autoDismiss)
    }

    private fun localizedPrayerName(key: String?): String = when (key) {
        "Fajr" -> getString(R.string.fajr)
        "Dhuhr" -> getString(R.string.dhuhr)
        "Asr" -> getString(R.string.asr)
        "Maghrib" -> getString(R.string.maghrib)
        "Isha" -> getString(R.string.isha)
        else -> ""
    }

    private fun setOnlineStatus(online: Boolean) {
        val colorRes = if (online) R.color.gold_accent else R.color.status_offline_red
        binding.statusDot.setColorFilter(ContextCompat.getColor(this, colorRes))
        binding.statusText.text = getString(if (online) R.string.online else R.string.offline)
    }

    companion object {
        private const val AUTO_DISMISS_MS = 3 * 60 * 1000L // 3 minutes
    }
}
