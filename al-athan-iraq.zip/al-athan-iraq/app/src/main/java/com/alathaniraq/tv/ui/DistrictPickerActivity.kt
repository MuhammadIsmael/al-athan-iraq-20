package com.alathaniraq.tv.ui

import android.Manifest
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.RecyclerView
import com.alathaniraq.tv.R
import com.alathaniraq.tv.data.District
import com.alathaniraq.tv.data.Governorate
import com.alathaniraq.tv.data.IraqRegions
import com.alathaniraq.tv.databinding.ActivityDistrictPickerBinding
import com.alathaniraq.tv.databinding.ItemRegionBinding
import com.alathaniraq.tv.util.LocationHelper
import com.alathaniraq.tv.util.Prefs

/**
 * Location picker with up to three steps: Governorate -> District -> Sub-district
 * (only shown for districts that actually have any — see IraqRegions.kt). The
 * system/D-pad back button steps back one level at a time before exiting the screen.
 * Also offers "Use My Location" (GPS) as a shortcut on the top-level governorate
 * screen, matching to the nearest district/sub-district automatically.
 */
class DistrictPickerActivity : BaseActivity() {

    private lateinit var binding: ActivityDistrictPickerBinding

    private enum class Step { GOVERNORATE, DISTRICT, SUB_DISTRICT }
    private var step: Step = Step.GOVERNORATE
    private var selectedGovernorate: Governorate? = null
    private var selectedDistrict: District? = null

    private val requestLocationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            useMyLocation()
        } else {
            showLocationStatus(getString(R.string.location_permission_denied))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDistrictPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.useLocationButton.setOnClickListener {
            if (LocationHelper.hasPermission(this)) {
                useMyLocation()
            } else {
                requestLocationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
        // Explicit initial D-pad focus for TV/TV-box remotes.
        binding.useLocationButton.requestFocus()

        showGovernorates()
    }

    override fun onBackPressed() {
        when (step) {
            Step.SUB_DISTRICT -> selectedGovernorate?.let { showDistricts(it) }
            Step.DISTRICT -> showGovernorates()
            Step.GOVERNORATE -> super.onBackPressed()
        }
    }

    private fun showGovernorates() {
        step = Step.GOVERNORATE
        selectedGovernorate = null
        selectedDistrict = null
        binding.pickerTitle.text = getString(R.string.select_governorate)
        binding.pickerHint.text = getString(R.string.select_governorate_hint)
        binding.useLocationButton.visibility = View.VISIBLE
        binding.regionGrid.adapter = RegionAdapter(IraqRegions.ALL.map { it.displayName }) { index ->
            showDistricts(IraqRegions.ALL[index])
        }
    }

    private fun showDistricts(governorate: Governorate) {
        step = Step.DISTRICT
        selectedGovernorate = governorate
        selectedDistrict = null
        binding.pickerTitle.text = governorate.displayName
        binding.pickerHint.text = getString(R.string.select_district_hint)
        binding.useLocationButton.visibility = View.GONE
        hideLocationStatus()
        binding.regionGrid.adapter = RegionAdapter(governorate.districts.map { it.displayName }) { index ->
            val district = governorate.districts[index]
            if (district.subDistricts.isEmpty()) {
                confirmSelection(district.id, null)
            } else {
                showSubDistricts(district)
            }
        }
    }

    private fun showSubDistricts(district: District) {
        step = Step.SUB_DISTRICT
        selectedDistrict = district
        binding.pickerTitle.text = district.displayName
        binding.pickerHint.text = getString(R.string.select_sub_district_hint)
        binding.useLocationButton.visibility = View.GONE
        hideLocationStatus()

        val labels = mutableListOf(getString(R.string.use_district_center, district.displayName))
        labels.addAll(district.subDistricts.map { it.displayName })

        binding.regionGrid.adapter = RegionAdapter(labels) { index ->
            if (index == 0) {
                confirmSelection(district.id, null)
            } else {
                confirmSelection(district.id, district.subDistricts[index - 1].id)
            }
        }
    }

    private fun confirmSelection(districtId: String, subDistrictId: String?) {
        Prefs.setDistrictAndSubDistrict(this, districtId, subDistrictId)
        setResult(RESULT_OK)
        finish()
    }

    private fun useMyLocation() {
        showLocationStatus(getString(R.string.locating))
        LocationHelper.getCurrentLocation(this) { location ->
            if (location == null) {
                showLocationStatus(getString(R.string.location_unavailable))
                return@getCurrentLocation
            }
            val (districtId, subDistrictId) = IraqRegions.nearestTo(location.latitude, location.longitude)
            Prefs.setDistrictAndSubDistrict(this, districtId, subDistrictId)
            val resolved = IraqRegions.resolveLocation(districtId, subDistrictId)
            showLocationStatus(getString(R.string.location_matched, resolved.displayName))
            binding.root.postDelayed({
                setResult(RESULT_OK)
                finish()
            }, 900)
        }
    }

    private fun showLocationStatus(text: String) {
        binding.locationStatus.text = text
        binding.locationStatus.visibility = View.VISIBLE
    }

    private fun hideLocationStatus() {
        binding.locationStatus.visibility = View.GONE
    }

    private class RegionAdapter(
        private val labels: List<String>,
        private val onClick: (Int) -> Unit
    ) : RecyclerView.Adapter<RegionAdapter.VH>() {

        inner class VH(val binding: ItemRegionBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val inflater = LayoutInflater.from(parent.context)
            val binding = ItemRegionBinding.inflate(inflater, parent, false)
            return VH(binding)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.binding.regionLabel.text = labels[position]
            holder.binding.root.setOnClickListener { onClick(position) }
        }

        override fun getItemCount(): Int = labels.size
    }
}
