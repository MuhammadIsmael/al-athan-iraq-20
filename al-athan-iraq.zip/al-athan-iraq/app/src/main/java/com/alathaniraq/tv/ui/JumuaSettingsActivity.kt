package com.alathaniraq.tv.ui

import android.app.Activity
import android.os.Bundle
import com.alathaniraq.tv.databinding.ActivityJumuaSettingsBinding
import com.alathaniraq.tv.util.Prefs

/**
 * Two ways to set Jumua (Friday prayer) time, matching the reference menu:
 * 1. Match Dhuhr exactly (offset ignored).
 * 2. Adjust +/- minutes relative to Dhuhr — can go negative (Jumua called before
 *    Dhuhr's adhan time) as well as positive (called after).
 */
class JumuaSettingsActivity : BaseActivity() {

    private lateinit var binding: ActivityJumuaSettingsBinding
    private var changed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJumuaSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.matchDhuhrButton.setOnClickListener {
            val newValue = !Prefs.getJumuaMatchDhuhr(this)
            Prefs.setJumuaMatchDhuhr(this, newValue)
            changed = true
            refreshUi()
        }

        binding.offsetMinus.setOnClickListener { adjustOffset(-1) }
        binding.offsetPlus.setOnClickListener { adjustOffset(1) }

        binding.doneButton.setOnClickListener { finish() }

        refreshUi()
        binding.matchDhuhrButton.requestFocus()
    }

    private fun adjustOffset(delta: Int) {
        // Adjusting the offset implicitly switches out of "match Dhuhr" mode — otherwise
        // the +/- buttons would appear to do nothing while match mode is on.
        if (Prefs.getJumuaMatchDhuhr(this)) {
            Prefs.setJumuaMatchDhuhr(this, false)
        }
        val current = Prefs.getJumuaOffset(this)
        val updated = (current + delta).coerceIn(MIN_OFFSET, MAX_OFFSET)
        if (updated != current) {
            Prefs.setJumuaOffset(this, updated)
        }
        changed = true
        refreshUi()
    }

    private fun refreshUi() {
        val matchDhuhr = Prefs.getJumuaMatchDhuhr(this)
        binding.matchDhuhrButton.setBackgroundResource(
            if (matchDhuhr) com.alathaniraq.tv.R.drawable.card_background_highlight
            else com.alathaniraq.tv.R.drawable.button_outline
        )
        binding.offsetRow.alpha = if (matchDhuhr) 0.5f else 1f

        val offset = Prefs.getJumuaOffset(this)
        binding.offsetValue.text = if (offset >= 0) "+$offset min" else "$offset min"
    }

    override fun finish() {
        setResult(if (changed) Activity.RESULT_OK else Activity.RESULT_CANCELED)
        super.finish()
    }

    companion object {
        private const val MIN_OFFSET = -60
        private const val MAX_OFFSET = 60
    }
}
